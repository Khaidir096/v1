<?php
// Warna Terminal
$biru = "\e[34m";
$k = "\e[33m";                                             $cyan = "\e[96m";
$magenta = "\e[35m";
$hijau = "\e[92m";
$m = "\e[91m";
$b = " \033[1m";

echo " $cyan$b Download 1 juta artikel :D \n TEKAN ENTER";
$uid 	= trim(fgets(STDIN));

echo " $k p-store.net/user/khaidiraje! ";

echo file_get_contents("https://pastebin.com/raw/TjcAzQrn");
     

echo "$hijau$b TEKAN ENTER ";
?>
