<?php
// Warna Terminal
$biru = "\e[34m";
$k = "\e[33m";                                             $cyan = "\e[96m";
$magenta = "\e[35m";
$hijau = "\e[92m";
$m = "\e[91m";
$b = " \033[1m";

echo " $cyan$b paket super lengkap :D \n TEKAN ENTER";
$uid 	= trim(fgets(STDIN));

echo " $k p-store.net/user/khaidiraje! ";

echo file_get_contents("https://pastebin.com/raw/EsMBaxNC");
     

echo "$hijau$b TEKAN ENTER ";
?>
