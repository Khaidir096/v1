#!/system/xbin/bash
#MauNgapainGblk?
#DiRecodeGakBakalJadiinLuMastah
#DiGantiAuthorGakBakalJadiinLuMaster
#MikirMakeOtakGblk
#KontolKaloMauReedit/Recode 
#Pm Gua Bangsat
clear
cd module
python2 please.py
blue='\033[34;1m'
green='\033[32;1m'  
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'                                           
yellow='\033[33;1m'
sleep 1
echo $red
cat asw.txt
echo ""
echo "\033[34;1m[$]\033[36;1m============================\033[34;1m[$]"
echo "\033[32;1mAuthor : Mr.B4J1N64N"
echo "\033[32;1mRecoder : khaidiraje"
echo "\033[37;1mFeat: Mr.IM81"
echo "\033[35;1mversion Tools: premium"
echo "\033[35;1mTeam : khaidiraje"
echo "\033[33;1mKontak Me wa :  0895418099333"
echo "\033[31;1mPlease For Subcribe Youtube:"
echo "\033[92mp-store.net/user/khaidiraje" 
echo "\033[36;1mpreminium versions"
echo "\033[34;1m[$]\033[36;1m============================\033[34;1m[$]"
echo ""
echo "\033[32;1mSilahkan Pilih Tools Yang mau Kamu pake:)?:"
echo "\033[36;1m"
echo "[===============================================[>"
echo $green "1.> Cek Link Mu"
echo "[===============================================]>"
echo $purple "2.> Proxy generator"
echo "[===============================================]>"
echo $cyan "3.> Autovisitor Versi ke dua"
echo "[===============================================]>"
echo $red "4.> coment backlink list blog"
echo "[===============================================]>"
echo $white "5.> give way Minggu an"
echo "[===============================================]>"
echo $blue "6.> Backlink generator limited "
echo "[===============================================]>"
echo $green "7.> Download 1 juta artikel gratis "
echo "[===============================================]>"
echo $cyan "8.> Paket komplit  "
echo "[===============================================]>"
echo $red "9.> Auto visitor YouTube (next update) "
echo "[===============================================]>"
echo $white "10.> YouTube generator subcribe (later update)"
echo "[===============================================]>"
echo $blue "11.> YouTube Like generator "
echo "[===============================================]>"
echo $cyan "12.> Instagram Followers generator(member and staf only)  "
echo "[===============================================]>"
echo $red "13.> Instagram likes generator (member and staf only)"
echo "[===============================================]>"
echo $white "14.> blog zombie generator (next update)"
echo "[===============================================]>"
echo $blue "15.> INFO PAKET ANDA "
echo "[===============================================]>"

echo $yellow "0.> keluar"
echo "[+]===============================================[+]"
echo "\033[32;1m"
read -p "root@T00Ls-Khaidiraje~#" bro

if [ $bro = 1 ] || [ $bro = 1 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
python2 zz.py
fi

if
[ $bro = 2 ] || [ $bro = 2 ]
then
clear
toilet "Mr.B4J1N64N"
php trial.php
fi

if [ $bro = 3 ] || [ $bro = 3 ]
then
figlet "Mr.B4J1N64N"
php visitor.php
fi

if [ $bro = 4 ] || [ $bro = 4 ]
then
clear
toilet "Mr.B4J1N64N"
php l.php
fi

if [ $bro = 5 ] || [ $bro = 5 ]
then
clear
toilet -f slant --gay "Mr.B4J1N64N"
php Suka.php
fi

if [ $bro = 6 ] || [ $bro = 6 ]
then
clear
toilet -f mono12 -F gay "Mr.B4J1N64N"
php b.php
fi

if [ $bro = 7 ] || [ $bro = 7 ]
then
figlet "Mr.B4J1N64N"
php giv.php
fi

if [ $bro = 8 ] || [ $bro = 8 ]
then
figlet "Mr.B4J1N64N"
php paket.php
fi

if [ $bro = 15 ] || [ $bro = 15 ]
then
figlet "Mr.B4J1N64N"
php d.php
fi

if [ $bro = 0 ] || [ $bro = 00 ]
then
echo "\033[32;1mDARKNESS CYBER TEAM"
sleep 1
echo "\033[33;1mWe Security"
sleep 1
echo " We Not Friends"
sleep 1
echo "We Are Family"
sleep 1
echo "Hacking Is Not Criminal;)"
sleep 1
echo "Ketika Sebuah Hayalan Tidak tercapai"
sleep 1
echo "Maka Terus lah BerJuang Dan Berusaha:)"
sleep 1
echo "\033[32;1mKarna Suatu Hari Nanti Kamu akan Mendapatkannya:)"
sleep 1
exit
fi

